# PermitFlow — Clean Rebuild

Includes backend (FastAPI), frontend (React placeholder), and Docker Compose.
